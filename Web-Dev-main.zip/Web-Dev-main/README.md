<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Mustafa</h1>
    <div class="job-title">Web Developer</div>
    <p>
        Hi, I'm Mustafa! I'm a web developer with a passion for creating beautiful and functional websites. 
    </p>

   <h2>Contact Information</h2>
    <ul>
        <li>Email: <a href="mailto:mustafa.mohd@dcmail.ca">mustafa.mohd@dcmail.ca</a></li>
        <li>Website: <a href="https://mustafamohdd.github.io/Web-Dev/">https://https://mustafamohdd.github.io/Web-Dev/</a></li>
        <li>Phone: <a href="tel:+1234567890">+123 456 7890</a></li>
    </ul>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="cool-box.css">
</head>
<body>
    <div class="cool-box">
        <h1>Cool Looking Box</h1>
        <p>This is a cool-looking box with a gradient background, rounded corners, and shadows.</p>
    </div>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="typesetting.css">
</head>
<body>
    <header>
        <h1>Welcome to My Homepage</h1>
        <nav>
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Contact</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <article>
            <h2>About Me</h2>
            <p>Hi, I'm Your Name! I love web development and design.</p>
        </article>
    </main>
    <footer>
        <p>&copy; 2023 Mustafa</p>
    </footer>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="layout.css">
</head>
<body>
    <header>
        <h1>Layout Comprehension</h1>
        <nav>
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Contact</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <article>
            <h2>Article Title</h2>
            <p>This is the main content of the article.</p>
            <img src="image1.jpg" alt="Image 1">
        </article>
        <aside>
            <h2>Sidebar</h2>
            <p>This is the sidebar content.</p>
        </aside>
    </main>
    <footer>
        <p>&copy; 2023 Mustafa</p>
    </footer>
</body>
</html>
